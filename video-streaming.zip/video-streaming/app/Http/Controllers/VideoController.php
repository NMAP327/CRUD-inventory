<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Video;
use Illuminate\Support\Facades\Storage;

class VideoController extends Controller
{
    // Menampilkan halaman upload video
    public function create()
    {
        return view('videos.create');
    }

    // Menyimpan video yang diupload
    public function store(Request $request)
    {
        $request->validate([
            'file_name' => 'required|string|max:255',
            'video_file' => 'required|mimetypes:video/mp4|max:2048'
        ]);

        $path = $request->file('video_file')->store('public/videos');
        $filename = $request->input('file_name');

        Video::create([
            'file_name' => $filename,
            'file_path' => $path
        ]);

        return redirect()->route('videos.index')->with('success', 'Video berhasil diupload');
    }

    // Menampilkan daftar video yang sudah diupload
    public function index()
    {
        $videos = Video::all();
        return view('videos.index', compact('videos'));
    }

    // Menampilkan halaman edit video
    public function edit($id)
    {
        $video = Video::findOrFail($id);
        return view('videos.edit', compact('video'));
    }

    // Mengupdate data video yang sudah diupload
    public function update(Request $request, $id)
    {
        $request->validate([
            'file_name' => 'required|string|max:255',
            'video_file' => 'nullable|mimetypes:video/mp4|max:2048'
        ]);

        $video = Video::findOrFail($id);
        $video->file_name = $request->input('file_name');

        if ($request->hasFile('video_file')) {
            Storage::delete($video->file_path);
            $path = $request->file('video_file')->store('public/videos');
            $video->file_path = $path;
        }

        $video->save();

        return redirect()->route('videos.index')->with('success', 'Video berhasil diupdate');
    }

    // Menghapus data video yang sudah diupload
    public function destroy($id)
    {
        $video = Video::findOrFail($id);
        Storage::delete($video->file_path);
        $video->delete();

        return redirect()->route('videos.index')->with('success', 'Video berhasil dihapus');
    }

    // Menampilkan video yang dipilih untuk di-streaming
    public function show($id)
    {
        $video = Video::findOrFail($id);
        $url = Storage::url($video->file_path);

        return view('videos.show', compact('url'));
    }
}
