<?php

use Illuminate\Support\Facades\Route;

// Menampilkan halaman utama
Route::get('/', function () {
    return view('videos.index');
});

// Menampilkan list video
Route::get('/videos', 'App\Http\Controllers\VideoController@index')->name('videos.index');

// Menampilkan halaman upload video
Route::get('/videos/upload', 'App\Http\Controllers\VideoController@create')->name('videos.create');

// Menyimpan video yang diupload
Route::post('/videos', 'App\Http\Controllers\VideoController@store')->name('videos.store');

// Menampilkan video yang dipilih
Route::get('/videos/{video}', 'App\Http\Controllers\VideoController@show')->name('videos.show');

// Menampilkan halaman edit video
Route::get('/videos/{video}/edit', 'App\Http\Controllers\VideoController@edit')->name('videos.edit');

// Menyimpan perubahan pada video yang diedit
Route::put('/videos/{video}', 'App\Http\Controllers\VideoController@update')->name('videos.update');

// Menghapus video
Route::delete('/videos/{video}', 'App\Http\Controllers\VideoController@destroy')->name('videos.destroy');


// Menampilkan halaman utama setelah login
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
