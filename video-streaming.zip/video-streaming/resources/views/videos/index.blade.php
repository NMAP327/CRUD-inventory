@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">List Video</div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama File</th>
                                    <th scope="col">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($videos as $video)
                                    <tr>
                                        <th scope="row">{{ $loop->iteration }}</th>
                                        <td>{{ $video->file_name }}</td>
                                        <td>
                                            <a href="{{ route('videos.show', $video->id) }}" class="btn btn-primary">Play</a>
                                            <a href="{{ route('videos.edit', $video->id) }}" class="btn btn-success">Edit</a>
                                            <form action="{{ route('videos.destroy', $video->id) }}" method="POST" style="display: inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus video ini?')">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <a href="{{ route('videos.create') }}" class="btn btn-primary">Upload Video</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
